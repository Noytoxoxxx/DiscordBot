-- new resource manifest https://docs.fivem.net/docs/scripting-reference/resource-manifest/resource-manifest/
fx_version 'bodacious'
-- https://docs.fivem.net/docs/scripting-reference/resource-manifest/resource-manifest/#fx-version-bodacious-2020-02
games {"gta5"}

author "Noytox"
description "Bot discord qui affiche les joueurs."
version "1.0.0"

server_script "bot.js"

shared_scripts "config.json"